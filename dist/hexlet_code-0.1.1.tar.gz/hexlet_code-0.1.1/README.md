### Hexlet tests and linter status:
[![Maintainability](https://api.codeclimate.com/v1/badges/4d55453efea58732ac3e/maintainability)](https://codeclimate.com/github/Nikolaykrasnov/python-project-49/maintainability)
[![Actions Status](https://github.com/Nikolaykrasnov/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Nikolaykrasnov/python-project-49/actions)

# brain-even
## Демонстрация
[![asciicast](https://asciinema.org/a/whwgecl9jsrv3Lpx3f3ZFSB2s)]
