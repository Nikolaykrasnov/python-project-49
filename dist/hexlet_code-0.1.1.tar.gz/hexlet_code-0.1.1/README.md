### Hexlet tests and linter status:
[![Maintainability](https://api.codeclimate.com/v1/badges/4d55453efea58732ac3e/maintainability)](https://codeclimate.com/github/Nikolaykrasnov/python-project-49/maintainability)
[![Actions Status](https://github.com/Nikolaykrasnov/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Nikolaykrasnov/python-project-49/actions)

# brain-even
## Демонстрация
[![asciicast](https://asciinema.org/a/whwgecl9jsrv3Lpx3f3ZFSB2s)]

# brain-calc 
[![asciicast](https://asciinema.org/a/QXug5ioP7fLAqf3yoD9UjBDoM)]

# brain-gcd
[![asciicast](https://asciinema.org/a/wmrX3cyaPFNIHm2NpBFm05tNm)]

# brain-progression
[![asciicast](https://asciinema.org/a/VXaKq6vzbZWkpr6nVJ42swqCl)]

